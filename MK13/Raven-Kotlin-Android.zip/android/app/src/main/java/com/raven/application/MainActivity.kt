package com.raven.application

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raven.application.bluetooth.BluetoothViewModel
import com.raven.application.ui.PermissionWrapper
import com.raven.application.ui.RavenApp
import com.raven.application.ui.theme.RavenTheme

/**
 * Raven Android entry point.
 *
 * UI/UX direction: a dark field-operations console with restrained green and
 * orange accents, asymmetric information hierarchy, and live mesh state.
 * Platform wiring stays here; feature behavior lives in Compose and ViewModels.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RavenTheme(dynamicColor = false) {
                PermissionWrapper {
                    val meshViewModel: BluetoothViewModel = viewModel()
                    RavenApp(meshViewModel = meshViewModel)
                }
            }
        }
    }
}
